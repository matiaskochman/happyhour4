package com.happyhour.email;

public interface NotificationService {
	public void sendMessage(String mailTo, String message);	
}
