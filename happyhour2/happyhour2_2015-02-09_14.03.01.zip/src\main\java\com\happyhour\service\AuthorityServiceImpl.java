package com.happyhour.service;

import org.springframework.stereotype.Service;

@Service(value="authorityService")
public class AuthorityServiceImpl implements AuthorityService {
}
