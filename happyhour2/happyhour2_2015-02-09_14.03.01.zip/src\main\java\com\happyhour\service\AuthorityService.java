package com.happyhour.service;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.happyhour.entity.Authority.class })
public interface AuthorityService {
}
